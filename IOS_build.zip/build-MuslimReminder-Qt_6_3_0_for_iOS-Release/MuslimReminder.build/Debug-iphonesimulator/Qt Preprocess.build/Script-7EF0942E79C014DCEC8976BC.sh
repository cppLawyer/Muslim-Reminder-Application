#!/bin/sh
make -C /Users/abdelaziz/Desktop/build-MuslimReminder-Qt_6_3_0_for_iOS-Release -f MuslimReminder.xcodeproj/qt_preprocess.mak
